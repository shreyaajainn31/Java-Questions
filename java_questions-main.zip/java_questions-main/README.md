# java_questions
A quiz game, sample for maintaining student's records and guest list in Java. 
